const express=require('express');
const app = express();
const PORT = 4000;

app.get('/',(request,response)=>{
    response.send('Welcome to college API !');
})
app.listen(PORT, () => {
    console.log(`Server started on port no :${PORT}`);
});